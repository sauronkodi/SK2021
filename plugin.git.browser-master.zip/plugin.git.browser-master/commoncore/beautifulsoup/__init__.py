try:
	from .bs4 import BeautifulSoup, Tag, NavigableString
except:
	from .BeautifulSoup import BeautifulSoup, Tag, NavigableString
